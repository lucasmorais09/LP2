﻿namespace PTesteLoops
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtFrase = new System.Windows.Forms.RichTextBox();
            this.btnContEspacos = new System.Windows.Forms.Button();
            this.btnContLetraR = new System.Windows.Forms.Button();
            this.btnContPares = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtFrase
            // 
            this.rchtFrase.Location = new System.Drawing.Point(142, 78);
            this.rchtFrase.MaxLength = 100;
            this.rchtFrase.Name = "rchtFrase";
            this.rchtFrase.Size = new System.Drawing.Size(177, 101);
            this.rchtFrase.TabIndex = 0;
            this.rchtFrase.Text = "";
            // 
            // btnContEspacos
            // 
            this.btnContEspacos.Location = new System.Drawing.Point(107, 222);
            this.btnContEspacos.Name = "btnContEspacos";
            this.btnContEspacos.Size = new System.Drawing.Size(114, 71);
            this.btnContEspacos.TabIndex = 1;
            this.btnContEspacos.Text = "Contar espaços em branco";
            this.btnContEspacos.UseVisualStyleBackColor = true;
            this.btnContEspacos.Click += new System.EventHandler(this.btnContEspacos_Click);
            // 
            // btnContLetraR
            // 
            this.btnContLetraR.Location = new System.Drawing.Point(255, 222);
            this.btnContLetraR.Name = "btnContLetraR";
            this.btnContLetraR.Size = new System.Drawing.Size(101, 71);
            this.btnContLetraR.TabIndex = 2;
            this.btnContLetraR.Text = "Contar letra \"R\"";
            this.btnContLetraR.UseVisualStyleBackColor = true;
            this.btnContLetraR.Click += new System.EventHandler(this.btnContLetraR_Click);
            // 
            // btnContPares
            // 
            this.btnContPares.Location = new System.Drawing.Point(416, 222);
            this.btnContPares.Name = "btnContPares";
            this.btnContPares.Size = new System.Drawing.Size(98, 71);
            this.btnContPares.TabIndex = 3;
            this.btnContPares.Text = "Contar pares de letras";
            this.btnContPares.UseVisualStyleBackColor = true;
            this.btnContPares.Click += new System.EventHandler(this.btnContPares_Click);
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnContPares);
            this.Controls.Add(this.btnContLetraR);
            this.Controls.Add(this.btnContEspacos);
            this.Controls.Add(this.rchtFrase);
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtFrase;
        private System.Windows.Forms.Button btnContEspacos;
        private System.Windows.Forms.Button btnContLetraR;
        private System.Windows.Forms.Button btnContPares;
    }
}