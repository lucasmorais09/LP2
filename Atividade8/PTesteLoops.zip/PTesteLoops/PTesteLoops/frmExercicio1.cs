﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace PTesteLoops
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnContEspacos_Click(object sender, EventArgs e)
        {
            string inpputFrase = rchtFrase.Text;
            int contEspacos = 0;

            for (int i = 0; i < inpputFrase.Length; i++)
            {
                if (Char.IsWhiteSpace(inpputFrase[i]))
                    contEspacos++;
            }

            MessageBox.Show(contEspacos.ToString());
        }

        private void btnContLetraR_Click(object sender, EventArgs e)
        {
            string inpputFrase = rchtFrase.Text;
            int contLetraR = 0;
        
            foreach(char i in inpputFrase)
            {
                if(Char.ToUpper(i) == 'R')
                    contLetraR++;
            }

            MessageBox.Show(contLetraR.ToString());
        }

        private void btnContPares_Click(object sender, EventArgs e)
        {
            string inpputFrase = rchtFrase.Text;
            int contPares = 0;
            int i = 0;
            char letraAnterior = '\0';

            while(i < inpputFrase.Length)
            {
                if (letraAnterior == Char.ToUpper(inpputFrase[i]))
                {
                    contPares++;
                }

                letraAnterior = Char.ToUpper(inpputFrase[i]);
                i++;
            }

            MessageBox.Show(contPares.ToString());
        }
    }
}
