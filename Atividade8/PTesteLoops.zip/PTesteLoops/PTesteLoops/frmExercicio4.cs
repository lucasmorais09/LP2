﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteLoops
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnCalcularSalario_Click(object sender, EventArgs e)
        {
            double salarioInicial = Convert.ToDouble(txtSalario.Text), salarioFinal;

            int A, B, C, D, producao = Convert.ToInt32(txtProducao.Text), gratificacao = Convert.ToInt32(txtGratificacao.Text);

            if(producao < 100)
            {
                B = 0;
                C = 0;
                D = 0;
            }
            else if(producao >= 100 & producao < 120)
            {
                B = 1;      
                C = 0;
                D = 0;
            }
            else if (producao >= 120 & producao < 150)
            {
                B = 1;
                C = 1;
                D = 0;
            }
            else
            {
                B = 1;
                C = 1;
                D = 1;
            }

            salarioFinal = salarioInicial + (salarioInicial*((0.05 * B) + (0.1 * C) + (0.1 + D))) + gratificacao;

            if(salarioFinal > 7000)
            {
                if (gratificacao >= 1)
                {
                    MessageBox.Show("O salário a ser recebido será: " + salarioFinal.ToString());
                }
                else
                {
                    MessageBox.Show("Não irá receber o salário: " + salarioFinal.ToString());
                }
            }
            else
            {
                MessageBox.Show("O salário a ser recebido será: " + salarioFinal.ToString());
            }
        }
    }
}
